using Microsoft.EntityFrameworkCore;
using InventoryHub.Api.Models;

namespace InventoryHub.Api.Data;

public class AppDbContext : DbContext
{
    public AppDbContext(DbContextOptions<AppDbContext> options)
        : base(options)
    {
    }

    public DbSet<Product> Products { get; set; } = null!;
}
